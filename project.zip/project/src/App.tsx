import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AuthForm } from './components/Auth/AuthForm';
import { Header } from './components/Layout/Header';
import { ClientDashboard } from './components/Dashboard/ClientDashboard';
import { FreelancerDashboard } from './components/Dashboard/FreelancerDashboard';
import { BrowseJobs } from './components/Projects/BrowseJobs';
import { ProjectDetails } from './components/Projects/ProjectDetails';
import { PostProject } from './components/Projects/PostProject';
import { MyProjects } from './components/Projects/MyProjects';
import { MyBids } from './components/Freelancer/MyBids';
import { MyContracts } from './components/Freelancer/MyContracts';
import { BrowseFreelancers } from './components/Freelancer/BrowseFreelancers';
import { Messages } from './components/Messages/Messages';
import { Profile } from './components/Profile/Profile';

function AppContent() {
  const { currentUser, userProfile, loading } = useAuth();
  const [currentView, setCurrentView] = useState('dashboard');
  const [viewData, setViewData] = useState<any>(null);

  const handleNavigate = (view: string, data?: any) => {
    setCurrentView(view);
    setViewData(data);
  };

  useEffect(() => {
    // Reset to dashboard when user changes
    if (currentUser && userProfile) {
      setCurrentView('dashboard');
      setViewData(null);
    }
  }, [currentUser, userProfile]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!currentUser || !userProfile) {
    return <AuthForm />;
  }

  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard':
        return userProfile.user_type === 'client' 
          ? <ClientDashboard onNavigate={handleNavigate} />
          : <FreelancerDashboard onNavigate={handleNavigate} />;
      
      case 'browse-jobs':
        return <BrowseJobs onNavigate={handleNavigate} />;
      
      case 'browse-freelancers':
        return <BrowseFreelancers onNavigate={handleNavigate} />;
      
      case 'project-details':
        return viewData ? <ProjectDetails project={viewData} onNavigate={handleNavigate} /> : null;
      
      case 'post-project':
        return <PostProject onNavigate={handleNavigate} />;
      
      case 'my-projects':
        return <MyProjects onNavigate={handleNavigate} />;
      
      case 'my-bids':
        return <MyBids onNavigate={handleNavigate} />;
      
      case 'my-contracts':
        return <MyContracts onNavigate={handleNavigate} />;
      
      case 'messages':
        return <Messages onNavigate={handleNavigate} />;
      
      case 'profile':
        return <Profile onNavigate={handleNavigate} />;
      
      default:
        return userProfile.user_type === 'client' 
          ? <ClientDashboard onNavigate={handleNavigate} />
          : <FreelancerDashboard onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onNavigate={handleNavigate} currentView={currentView} />
      {renderCurrentView()}
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;