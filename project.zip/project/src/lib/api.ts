export const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000/api';

async function http<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options?.headers || {}) },
    ...options,
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export const ProjectsApi = {
  create: (body: any) => http('/projects', { method: 'POST', body: JSON.stringify(body) }),
  listOpen: () => http('/projects'),
  get: (id: string) => http(`/projects/${id}`),
};

export const BidsApi = {
  create: (body: any) => http('/bids', { method: 'POST', body: JSON.stringify(body) }),
  accept: (bidId: string) => http('/bids/accept', { method: 'POST', body: JSON.stringify({ bidId }) }),
  listByProject: (projectId: string) => http(`/bids/of-project/${projectId}`),
  listByUser: (freelancerId: string) => http(`/bids/of-user/${freelancerId}`),
};

export const ContractsApi = {
  listMine: (userId: string) => http(`/contracts/me/${userId}`),
  updateMilestone: (id: string, status: string) => http(`/contracts/milestones/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) }),
};

export const MessagesApi = {
  conversations: (userId: string) => http(`/messages/conversations/${userId}`),
  thread: (userId: string, partnerId: string) => http(`/messages/${userId}/${partnerId}`),
  send: (body: any) => http('/messages', { method: 'POST', body: JSON.stringify(body) }),
};

export const StripeApi = {
  createPaymentIntent: (amount: number, currency = 'usd') => http('/stripe/payment-intents', { method: 'POST', body: JSON.stringify({ amount, currency }) }),
};
