export interface User {
  id: string;
  email: string;
  full_name: string;
  avatar_url?: string;
  user_type: 'client' | 'freelancer';
  bio?: string;
  skills?: string[];
  hourly_rate?: number;
  location?: string;
  rating?: number;
  total_jobs?: number;
  created_at: string;
  updated_at: string;
}

export interface Project {
  id: string;
  client_id: string;
  title: string;
  description: string;
  category: string;
  budget_min: number;
  budget_max: number;
  duration: string;
  skills_required: string[];
  status: 'open' | 'in_progress' | 'completed' | 'cancelled';
  created_at: string;
  updated_at: string;
  client?: User;
  bids_count?: number;
}

export interface Bid {
  id: string;
  project_id: string;
  freelancer_id: string;
  amount: number;
  proposal: string;
  delivery_time: number;
  status: 'pending' | 'accepted' | 'rejected';
  created_at: string;
  updated_at: string;
  freelancer?: User;
  project?: Project;
}

export interface Contract {
  id: string;
  project_id: string;
  client_id: string;
  freelancer_id: string;
  bid_id: string;
  amount: number;
  status: 'active' | 'completed' | 'cancelled' | 'disputed';
  milestones?: Milestone[];
  created_at: string;
  updated_at: string;
  project?: Project;
  client?: User;
  freelancer?: User;
}

export interface Milestone {
  id: string;
  contract_id: string;
  title: string;
  description: string;
  amount: number;
  status: 'pending' | 'in_progress' | 'completed' | 'approved';
  due_date?: string;
  created_at: string;
  updated_at: string;
}

export interface Message {
  id: string;
  project_id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  is_read: boolean;
  created_at: string;
  sender?: User;
  receiver?: User;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: 'bid' | 'message' | 'contract' | 'milestone' | 'system';
  is_read: boolean;
  related_id?: string;
  created_at: string;
}