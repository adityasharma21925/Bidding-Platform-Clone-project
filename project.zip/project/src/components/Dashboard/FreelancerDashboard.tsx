import React from 'react';
import { Search, Briefcase, MessageCircle, Star, TrendingUp, DollarSign } from 'lucide-react';

interface FreelancerDashboardProps {
  onNavigate: (view: string) => void;
}

export const FreelancerDashboard = ({ onNavigate }: FreelancerDashboardProps) => {
  const stats = [
    { name: 'Active Contracts', value: '2', icon: Briefcase, color: 'blue' },
    { name: 'This Month', value: '$3,200', icon: DollarSign, color: 'green' },
    { name: 'Client Rating', value: '4.9', icon: Star, color: 'yellow' },
    { name: 'Success Rate', value: '98%', icon: TrendingUp, color: 'purple' },
  ];

  const recentBids = [
    {
      id: '1',
      project: 'React Dashboard Development',
      amount: 1500,
      status: 'pending',
      client: 'TechCorp Inc.',
      submitted: '2 hours ago',
    },
    {
      id: '2',
      project: 'API Integration Project',
      amount: 800,
      status: 'accepted',
      client: 'StartupXYZ',
      submitted: '1 day ago',
    },
    {
      id: '3',
      project: 'Mobile App Development',
      amount: 2200,
      status: 'rejected',
      client: 'Digital Agency',
      submitted: '3 days ago',
    },
  ];

  const activeContracts = [
    {
      id: '1',
      project: 'E-commerce Platform',
      client: 'ShopMaster LLC',
      progress: 75,
      deadline: '2025-02-20',
      amount: 3500,
    },
    {
      id: '2',
      project: 'CRM System Updates',
      client: 'BusinessPro',
      progress: 40,
      deadline: '2025-02-28',
      amount: 1200,
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Freelancer Dashboard</h1>
          <p className="text-gray-600 mt-1">Find projects and grow your freelance career</p>
        </div>
        <button
          onClick={() => onNavigate('browse-jobs')}
          className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-lg font-medium hover:from-blue-700 hover:to-purple-700 transition-colors flex items-center space-x-2"
        >
          <Search className="w-5 h-5" />
          <span>Browse Jobs</span>
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.name} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center bg-${stat.color}-100`}>
                  <Icon className={`w-6 h-6 text-${stat.color}-600`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Bids */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-900">Recent Bids</h2>
              <button
                onClick={() => onNavigate('my-bids')}
                className="text-blue-600 hover:text-blue-700 text-sm font-medium"
              >
                View All
              </button>
            </div>
          </div>
          <div className="divide-y divide-gray-200">
            {recentBids.map((bid) => (
              <div key={bid.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-medium text-gray-900">{bid.project}</h3>
                    <div className="mt-2 flex items-center space-x-4 text-sm text-gray-600">
                      <span className="font-medium">${bid.amount}</span>
                      <span>{bid.client}</span>
                      <span>{bid.submitted}</span>
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    bid.status === 'accepted'
                      ? 'bg-green-100 text-green-800'
                      : bid.status === 'pending'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {bid.status.toUpperCase()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Active Contracts */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-900">Active Contracts</h2>
              <button
                onClick={() => onNavigate('my-contracts')}
                className="text-blue-600 hover:text-blue-700 text-sm font-medium"
              >
                View All
              </button>
            </div>
          </div>
          <div className="divide-y divide-gray-200">
            {activeContracts.map((contract) => (
              <div key={contract.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-medium text-gray-900">{contract.project}</h3>
                  <span className="text-lg font-bold text-green-600">${contract.amount}</span>
                </div>
                <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                  <span>{contract.client}</span>
                  <span>Due: {contract.deadline}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{ width: `${contract.progress}%` }}
                  ></div>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <span className="text-sm text-gray-600">Progress: {contract.progress}%</span>
                  <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
                    View Details
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};