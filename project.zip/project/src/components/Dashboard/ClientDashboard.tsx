import React from 'react';
import { PlusCircle, Briefcase, MessageCircle, Star, TrendingUp, Users } from 'lucide-react';

interface ClientDashboardProps {
  onNavigate: (view: string) => void;
}

export const ClientDashboard = ({ onNavigate }: ClientDashboardProps) => {
  const stats = [
    { name: 'Active Projects', value: '3', icon: Briefcase, color: 'blue' },
    { name: 'Total Hired', value: '12', icon: Users, color: 'green' },
    { name: 'Avg Rating', value: '4.8', icon: Star, color: 'yellow' },
    { name: 'Success Rate', value: '95%', icon: TrendingUp, color: 'purple' },
  ];

  const recentProjects = [
    {
      id: '1',
      title: 'E-commerce Website Development',
      status: 'in_progress',
      freelancer: 'John Doe',
      budget: 2500,
      deadline: '2025-02-15',
    },
    {
      id: '2',
      title: 'Mobile App UI Design',
      status: 'completed',
      freelancer: 'Jane Smith',
      budget: 1200,
      deadline: '2025-01-30',
    },
    {
      id: '3',
      title: 'Database Optimization',
      status: 'open',
      freelancer: null,
      budget: 800,
      deadline: '2025-02-20',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Client Dashboard</h1>
          <p className="text-gray-600 mt-1">Manage your projects and find talented freelancers</p>
        </div>
        <button
          onClick={() => onNavigate('post-project')}
          className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-lg font-medium hover:from-blue-700 hover:to-purple-700 transition-colors flex items-center space-x-2"
        >
          <PlusCircle className="w-5 h-5" />
          <span>Post New Project</span>
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.name} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center bg-${stat.color}-100`}>
                  <Icon className={`w-6 h-6 text-${stat.color}-600`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Projects */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-900">Recent Projects</h2>
            <button
              onClick={() => onNavigate('my-projects')}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium"
            >
              View All
            </button>
          </div>
        </div>
        <div className="divide-y divide-gray-200">
          {recentProjects.map((project) => (
            <div key={project.id} className="p-6 hover:bg-gray-50 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-medium text-gray-900">{project.title}</h3>
                  <div className="mt-2 flex items-center space-x-4 text-sm text-gray-600">
                    <span className="flex items-center">
                      <Briefcase className="w-4 h-4 mr-1" />
                      ${project.budget}
                    </span>
                    <span>Due: {project.deadline}</span>
                    {project.freelancer && (
                      <span className="flex items-center">
                        <Users className="w-4 h-4 mr-1" />
                        {project.freelancer}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    project.status === 'completed'
                      ? 'bg-green-100 text-green-800'
                      : project.status === 'in_progress'
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {project.status.replace('_', ' ').toUpperCase()}
                  </span>
                  <button className="text-gray-400 hover:text-gray-600">
                    <MessageCircle className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};