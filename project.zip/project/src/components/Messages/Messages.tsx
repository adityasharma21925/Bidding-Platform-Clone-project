import React, { useState, useEffect } from 'react';
import { Search, Send, User, Clock } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Message, User as UserType } from '../../types';
import { useNotifications } from '../../hooks/useNotifications';

interface MessagesProps {
  onNavigate: (view: string) => void;
}

export const Messages = ({ onNavigate }: MessagesProps) => {
  const { userProfile } = useAuth();
  const { createNotification } = useNotifications();
  const [conversations, setConversations] = useState<any[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sendingMessage, setSendingMessage] = useState(false);

  useEffect(() => {
    fetchConversations();
  }, []);

  useEffect(() => {
    if (selectedConversation) {
      fetchMessages(selectedConversation);
    }
  }, [selectedConversation]);

  const fetchConversations = async () => {
    if (!userProfile) return;

    try {
      // Get all unique conversations for this user
      const { data: messageData, error } = await supabase
        .from('messages')
        .select(`
          sender_id,
          receiver_id,
          created_at,
          content,
          is_read,
          project_id,
          sender:users!messages_sender_id_fkey(id, full_name, avatar_url),
          receiver:users!messages_receiver_id_fkey(id, full_name, avatar_url),
          project:projects(title)
        `)
        .or(`sender_id.eq.${userProfile.id},receiver_id.eq.${userProfile.id}`)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Group messages by conversation partner
      const conversationsMap = new Map();
      
      messageData?.forEach((message) => {
        const partnerId = message.sender_id === userProfile.id ? message.receiver_id : message.sender_id;
        const partner = message.sender_id === userProfile.id ? message.receiver : message.sender;
        
        if (!conversationsMap.has(partnerId)) {
          conversationsMap.set(partnerId, {
            partnerId,
            partner,
            lastMessage: message,
            unreadCount: 0,
            project: message.project
          });
        }
        
        // Count unread messages
        if (!message.is_read && message.receiver_id === userProfile.id) {
          conversationsMap.get(partnerId).unreadCount++;
        }
      });

      setConversations(Array.from(conversationsMap.values()));
    } catch (error) {
      console.error('Error fetching conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async (partnerId: string) => {
    if (!userProfile) return;

    try {
      const { data, error } = await supabase
        .from('messages')
        .select(`
          *,
          sender:users!messages_sender_id_fkey(full_name, avatar_url),
          receiver:users!messages_receiver_id_fkey(full_name, avatar_url)
        `)
        .or(
          `and(sender_id.eq.${userProfile.id},receiver_id.eq.${partnerId}),and(sender_id.eq.${partnerId},receiver_id.eq.${userProfile.id})`
        )
        .order('created_at', { ascending: true });

      if (error) throw error;
      setMessages(data || []);

      // Mark messages as read
      await supabase
        .from('messages')
        .update({ is_read: true })
        .eq('sender_id', partnerId)
        .eq('receiver_id', userProfile.id);

      // Refresh conversations to update unread counts
      fetchConversations();
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userProfile || !selectedConversation || !newMessage.trim()) return;

    setSendingMessage(true);
    try {
      const { error } = await supabase.from('messages').insert([
        {
          sender_id: userProfile.id,
          receiver_id: selectedConversation,
          content: newMessage.trim(),
        },
      ]);

      if (error) throw error;

      // Create notification for receiver
      const receiverName = conversations.find(c => c.partnerId === selectedConversation)?.partner?.full_name || 'Someone';
      await createNotification(
        selectedConversation,
        'New Message',
        `${userProfile.full_name} sent you a message`,
        'message'
      );

      setNewMessage('');
      fetchMessages(selectedConversation);
      fetchConversations();
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setSendingMessage(false);
    }
  };

  const timeAgo = (date: string) => {
    const now = new Date();
    const messageTime = new Date(date);
    const diffInMinutes = Math.floor((now.getTime() - messageTime.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
  };

  const selectedPartner = conversations.find(c => c.partnerId === selectedConversation);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden" style={{ height: '600px' }}>
        <div className="flex h-full">
          {/* Conversations List */}
          <div className="w-1/3 border-r border-gray-200 flex flex-col">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Messages</h2>
            </div>
            
            <div className="flex-1 overflow-y-auto">
              {loading ? (
                <div className="p-4 text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                </div>
              ) : conversations.length === 0 ? (
                <div className="p-4 text-center text-gray-600">
                  <p>No conversations yet</p>
                  <p className="text-sm mt-1">Start by messaging clients or freelancers</p>
                </div>
              ) : (
                conversations.map((conversation) => (
                  <div
                    key={conversation.partnerId}
                    onClick={() => setSelectedConversation(conversation.partnerId)}
                    className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 ${
                      selectedConversation === conversation.partnerId ? 'bg-blue-50 border-blue-200' : ''
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center">
                        <User className="w-5 h-5 text-gray-600" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium text-gray-900">{conversation.partner.full_name}</h3>
                          <span className="text-xs text-gray-500">
                            {timeAgo(conversation.lastMessage.created_at)}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 truncate">
                          {conversation.lastMessage.content}
                        </p>
                        {conversation.project && (
                          <p className="text-xs text-blue-600 mt-1">
                            Re: {conversation.project.title}
                          </p>
                        )}
                      </div>
                      {conversation.unreadCount > 0 && (
                        <span className="w-5 h-5 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs">
                          {conversation.unreadCount}
                        </span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Message Thread */}
          <div className="flex-1 flex flex-col">
            {selectedConversation && selectedPartner ? (
              <>
                {/* Header */}
                <div className="p-4 border-b border-gray-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                      <User className="w-4 h-4 text-gray-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">{selectedPartner.partner.full_name}</h3>
                      {selectedPartner.project && (
                        <p className="text-sm text-gray-600">Project: {selectedPartner.project.title}</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.sender_id === userProfile?.id ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                          message.sender_id === userProfile?.id
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-900'
                        }`}
                      >
                        <p>{message.content}</p>
                        <p
                          className={`text-xs mt-1 ${
                            message.sender_id === userProfile?.id ? 'text-blue-100' : 'text-gray-500'
                          }`}
                        >
                          {timeAgo(message.created_at)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Message Input */}
                <div className="p-4 border-t border-gray-200">
                  <form onSubmit={sendMessage} className="flex space-x-2">
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Type your message..."
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                    <button
                      type="submit"
                      disabled={sendingMessage || !newMessage.trim()}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-gray-500">
                <div className="text-center">
                  <User className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                  <p>Select a conversation to start messaging</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};