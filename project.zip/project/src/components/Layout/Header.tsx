import React from 'react';

interface HeaderProps {
  onNavigate: (view: string, data?: any) => void;
  currentView: string;
}

export const Header: React.FC<HeaderProps> = ({ onNavigate, currentView }) => {
  const NavButton = ({ view, label }: { view: string; label: string }) => (
    <button
      onClick={() => onNavigate(view)}
      className={`px-3 py-2 rounded-md text-sm font-medium ${
        currentView === view ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'
      }`}
    >
      {label}
    </button>
  );

  return (
    <header className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="text-lg font-semibold text-gray-900">Freelance Marketplace</div>
        <nav className="flex items-center space-x-2">
          <NavButton view="dashboard" label="Dashboard" />
          <NavButton view="browse-jobs" label="Browse Jobs" />
          <NavButton view="my-bids" label="My Bids" />
          <NavButton view="my-contracts" label="My Contracts" />
          <NavButton view="messages" label="Messages" />
          <NavButton view="profile" label="Profile" />
        </nav>
      </div>
    </header>
  );
};

export default Header;