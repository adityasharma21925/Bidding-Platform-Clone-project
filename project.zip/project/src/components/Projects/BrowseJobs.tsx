import React, { useState, useEffect } from 'react';
import { Search, Filter, MapPin, DollarSign, Clock, User, Star } from 'lucide-react';
import { ProjectsApi } from '../../lib/api';
import { Project } from '../../types';
import { useAuth } from '../../contexts/AuthContext';

interface BrowseJobsProps {
  onNavigate: (view: string, data?: any) => void;
}

export const BrowseJobs = ({ onNavigate }: BrowseJobsProps) => {
  const { userProfile } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [budgetFilter, setBudgetFilter] = useState('all');

  const categories = [
    'all', 'Web Development', 'Mobile Development', 'Design', 
    'Writing', 'Marketing', 'Data Science', 'DevOps'
  ];

  const budgetRanges = [
    { label: 'All Budgets', value: 'all' },
    { label: 'Under $500', value: '0-500' },
    { label: '$500 - $1000', value: '500-1000' },
    { label: '$1000 - $5000', value: '1000-5000' },
    { label: 'Over $5000', value: '5000+' },
  ];

  useEffect(() => {
    fetchProjects();
  }, [searchTerm, categoryFilter, budgetFilter]);

  const fetchProjects = async () => {
    setLoading(true);
    try {
      const data: any[] = await ProjectsApi.listOpen();
      let rows = data.map((p) => ({
        id: p._id,
        client_id: p.client,
        title: p.title,
        description: p.description,
        category: p.category,
        budget_min: p.budgetMin,
        budget_max: p.budgetMax,
        duration: p.duration,
        skills_required: p.skillsRequired || [],
        status: p.status,
        created_at: p.createdAt,
        updated_at: p.updatedAt,
      }));

      if (searchTerm) {
        const term = searchTerm.toLowerCase();
        rows = rows.filter(r => r.title.toLowerCase().includes(term) || r.description.toLowerCase().includes(term));
      }
      if (categoryFilter !== 'all') {
        rows = rows.filter(r => r.category === categoryFilter);
      }
      if (budgetFilter !== 'all') {
        const [minStr, maxStr] = budgetFilter.split('-');
        const min = parseInt(minStr);
        if (maxStr === '+') {
          rows = rows.filter(r => r.budget_min >= min);
        } else {
          const max = parseInt(maxStr);
          rows = rows.filter(r => r.budget_min >= min && r.budget_max <= max);
        }
      }

      setProjects(rows);
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleProjectClick = (project: Project) => {
    onNavigate('project-details', project);
  };

  const timeAgo = (date: string) => {
    const now = new Date();
    const posted = new Date(date);
    const diffInHours = Math.floor((now.getTime() - posted.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const days = Math.floor(diffInHours / 24);
    return `${days}d ago`;
  };

  if (userProfile?.user_type !== 'freelancer') {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Access Restricted</h2>
          <p className="text-gray-600">Only freelancers can browse jobs.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Browse Jobs</h1>
        <p className="text-gray-600">Find your next freelance opportunity</p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search projects..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            {categories.map((category) => (
              <option key={category} value={category}>
                {category === 'all' ? 'All Categories' : category}
              </option>
            ))}
          </select>

          <select
            value={budgetFilter}
            onChange={(e) => setBudgetFilter(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            {budgetRanges.map((range) => (
              <option key={range.value} value={range.value}>
                {range.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Results */}
      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-gray-600 mt-4">Loading projects...</p>
        </div>
      ) : projects.length === 0 ? (
        <div className="text-center py-12">
          <h3 className="text-lg font-medium text-gray-900 mb-2">No projects found</h3>
          <p className="text-gray-600">Try adjusting your search criteria</p>
        </div>
      ) : (
        <div className="space-y-6">
          {projects.map((project) => (
            <div
              key={project.id}
              onClick={() => handleProjectClick(project)}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow cursor-pointer"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2 hover:text-blue-600 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-gray-600 line-clamp-3">{project.description}</p>
                </div>
                <div className="ml-6 text-right">
                  <div className="text-2xl font-bold text-green-600">
                    ${project.budget_min} - ${project.budget_max}
                  </div>
                  <div className="text-sm text-gray-600">{project.duration}</div>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mb-4">
                {project.skills_required.map((skill) => (
                  <span
                    key={skill}
                    className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                  >
                    {skill}
                  </span>
                ))}
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-6 text-sm text-gray-600">
                  <div className="flex items-center space-x-1">
                    <User className="w-4 h-4" />
                    <span>{project.client?.full_name}</span>
                    {project.client?.rating && (
                      <div className="flex items-center space-x-1">
                        <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        <span>{project.client.rating.toFixed(1)}</span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{timeAgo(project.created_at)}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Filter className="w-4 h-4" />
                    <span>{project.bids_count || 0} bids</span>
                  </div>
                </div>
                <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                  {project.category}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};