import React, { useState, useEffect } from 'react';
import { ArrowLeft, MapPin, Clock, DollarSign, User, Star, Send } from 'lucide-react';
import { BidsApi } from '../../lib/api';
import { useAuth } from '../../contexts/AuthContext';
import { Project, Bid } from '../../types';
import { useNotifications } from '../../hooks/useNotifications';

interface ProjectDetailsProps {
  project: Project;
  onNavigate: (view: string, data?: any) => void;
}

export const ProjectDetails = ({ project, onNavigate }: ProjectDetailsProps) => {
  const { userProfile } = useAuth();
  const { createNotification } = useNotifications();
  const [bids, setBids] = useState<Bid[]>([]);
  const [loading, setLoading] = useState(true);
  const [showBidForm, setShowBidForm] = useState(false);
  const [bidData, setBidData] = useState({
    amount: '',
    proposal: '',
    delivery_time: '',
  });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchBids();
  }, [project.id]);

  const fetchBids = async () => {
    try {
      const data: any[] = await BidsApi.listByProject(project.id);
      const rows: any[] = data.map((b) => ({
        id: b._id,
        project_id: project.id,
        freelancer_id: b.freelancer,
        amount: b.amount,
        proposal: b.proposal,
        delivery_time: b.deliveryTime,
        status: b.status,
        created_at: b.createdAt,
        updated_at: b.updatedAt,
      }));
      setBids(rows as any);
    } catch (error) {
      console.error('Error fetching bids:', error);
    } finally {
      setLoading(false);
    }
  };

  const submitBid = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userProfile) return;

    setSubmitting(true);
    try {
      await BidsApi.create({
        projectId: project.id,
        freelancerId: userProfile.id,
        amount: parseFloat(bidData.amount),
        proposal: bidData.proposal,
        deliveryTime: parseInt(bidData.delivery_time),
      });

      // Create notification for project owner
      await createNotification(
        project.client_id,
        'New Bid Received',
        `${userProfile.full_name} submitted a bid of $${bidData.amount} for your project "${project.title}"`,
        'bid',
        project.id
      );
      setBidData({ amount: '', proposal: '', delivery_time: '' });
      setShowBidForm(false);
      fetchBids();
    } catch (error) {
      console.error('Error submitting bid:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const acceptBid = async (bid: Bid) => {
    try {
      await BidsApi.accept(bid.id);
      await createNotification(
        bid.freelancer_id,
        'Bid Accepted!',
        `Your bid for "${project.title}" has been accepted. A new contract has been created.`,
        'contract',
        project.id
      );

      onNavigate('my-projects');
    } catch (error) {
      console.error('Error accepting bid:', error);
    }
  };

  const hasUserBid = bids.some(bid => bid.freelancer_id === userProfile?.id);
  const isProjectOwner = userProfile?.id === project.client_id;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Back Button */}
      <button
        onClick={() => onNavigate('browse-jobs')}
        className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back to Jobs</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">{project.title}</h1>
            
            <div className="flex items-center space-x-6 mb-6 text-gray-600">
              <div className="flex items-center space-x-1">
                <DollarSign className="w-5 h-5" />
                <span className="font-semibold text-green-600">
                  ${project.budget_min} - ${project.budget_max}
                </span>
              </div>
              <div className="flex items-center space-x-1">
                <Clock className="w-5 h-5" />
                <span>{project.duration}</span>
              </div>
              <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                {project.category}
              </span>
            </div>

            <div className="prose max-w-none mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Project Description</h3>
              <p className="text-gray-700 whitespace-pre-wrap">{project.description}</p>
            </div>

            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Required Skills</h3>
              <div className="flex flex-wrap gap-2">
                {project.skills_required.map((skill) => (
                  <span
                    key={skill}
                    className="px-3 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Client Info */}
            <div className="border-t border-gray-200 pt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">About the Client</h3>
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-gray-600" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">{project.client?.full_name}</h4>
                  {project.client?.rating && (
                    <div className="flex items-center space-x-1 text-sm text-gray-600">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span>{project.client.rating.toFixed(1)} rating</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="lg:col-span-1">
          {/* Bid Form */}
          {userProfile?.user_type === 'freelancer' && !hasUserBid && !showBidForm && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
              <button
                onClick={() => setShowBidForm(true)}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 px-4 rounded-lg font-medium hover:from-blue-700 hover:to-purple-700 transition-colors flex items-center justify-center space-x-2"
              >
                <Send className="w-5 h-5" />
                <span>Submit Proposal</span>
              </button>
            </div>
          )}

          {showBidForm && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Submit Your Proposal</h3>
              <form onSubmit={submitBid} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Your Bid ($)
                  </label>
                  <input
                    type="number"
                    required
                    value={bidData.amount}
                    onChange={(e) => setBidData({ ...bidData, amount: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter your bid amount"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Delivery Time (days)
                  </label>
                  <input
                    type="number"
                    required
                    value={bidData.delivery_time}
                    onChange={(e) => setBidData({ ...bidData, delivery_time: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Days to complete"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Cover Letter
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={bidData.proposal}
                    onChange={(e) => setBidData({ ...bidData, proposal: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Describe why you're perfect for this project..."
                  />
                </div>

                <div className="flex space-x-3">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  >
                    {submitting ? 'Submitting...' : 'Submit Bid'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowBidForm(false)}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Bids List */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Proposals ({bids.length})
            </h3>
            
            {loading ? (
              <div className="text-center py-4">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
              </div>
            ) : bids.length === 0 ? (
              <p className="text-gray-600 text-center py-4">No proposals yet</p>
            ) : (
              <div className="space-y-4">
                {bids.map((bid) => (
                  <div key={bid.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                          <User className="w-4 h-4 text-gray-600" />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">
                            {bid.freelancer?.full_name}
                          </h4>
                          {bid.freelancer?.rating && (
                            <div className="flex items-center space-x-1 text-xs text-gray-600">
                              <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                              <span>{bid.freelancer.rating.toFixed(1)}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-green-600">${bid.amount}</div>
                        <div className="text-xs text-gray-600">{bid.delivery_time} days</div>
                      </div>
                    </div>
                    
                    <p className="text-sm text-gray-700 mb-3 line-clamp-3">{bid.proposal}</p>
                    
                    {bid.freelancer?.skills && (
                      <div className="flex flex-wrap gap-1 mb-3">
                        {bid.freelancer.skills.slice(0, 3).map((skill) => (
                          <span
                            key={skill}
                            className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    )}

                    {isProjectOwner && bid.status === 'pending' && (
                      <button
                        onClick={() => acceptBid(bid)}
                        className="w-full bg-green-600 text-white py-2 px-4 rounded-lg text-sm hover:bg-green-700 transition-colors"
                      >
                        Accept Proposal
                      </button>
                    )}

                    {bid.status !== 'pending' && (
                      <div className={`text-center py-2 rounded-lg text-sm font-medium ${
                        bid.status === 'accepted' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {bid.status.toUpperCase()}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};