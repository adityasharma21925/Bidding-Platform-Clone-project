import React, { useState, useEffect } from 'react';
import { Search, Clock, DollarSign, User, CheckCircle, MessageCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Contract } from '../../types';

interface MyContractsProps {
  onNavigate: (view: string, data?: any) => void;
}

export const MyContracts = ({ onNavigate }: MyContractsProps) => {
  const { userProfile } = useAuth();
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    fetchContracts();
  }, [searchTerm, statusFilter]);

  const fetchContracts = async () => {
    if (!userProfile) return;

    setLoading(true);
    try {
      let query = supabase
        .from('contracts')
        .select(`
          *,
          project:projects!contracts_project_id_fkey(
            id,
            title,
            description,
            category,
            duration
          ),
          client:users!contracts_client_id_fkey(
            id,
            full_name,
            avatar_url,
            rating
          ),
          milestones(
            id,
            title,
            status,
            amount
          )
        `)
        .eq('freelancer_id', userProfile.id)
        .order('created_at', { ascending: false });

      if (statusFilter !== 'all') {
        query = query.eq('status', statusFilter);
      }

      const { data, error } = await query;
      if (error) throw error;

      let filteredContracts = data || [];
      if (searchTerm) {
        filteredContracts = filteredContracts.filter(contract =>
          contract.project?.title.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }

      setContracts(filteredContracts);
    } catch (error) {
      console.error('Error fetching contracts:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      case 'disputed':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const calculateProgress = (milestones: any[]) => {
    if (!milestones || milestones.length === 0) return 0;
    const completedCount = milestones.filter(m => m.status === 'completed' || m.status === 'approved').length;
    return Math.round((completedCount / milestones.length) * 100);
  };

  const timeAgo = (date: string) => {
    const now = new Date();
    const started = new Date(date);
    const diffInDays = Math.floor((now.getTime() - started.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) return 'Started today';
    if (diffInDays === 1) return 'Started 1 day ago';
    return `Started ${diffInDays} days ago`;
  };

  if (userProfile?.user_type !== 'freelancer') {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Access Restricted</h2>
          <p className="text-gray-600">Only freelancers can view this page.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">My Contracts</h1>
        <p className="text-gray-600 mt-1">Manage your active and completed projects</p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search by project title..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
            <option value="disputed">Disputed</option>
          </select>
        </div>
      </div>

      {/* Contracts List */}
      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-gray-600 mt-4">Loading contracts...</p>
        </div>
      ) : contracts.length === 0 ? (
        <div className="text-center py-12">
          <h3 className="text-lg font-medium text-gray-900 mb-2">No contracts found</h3>
          <p className="text-gray-600 mb-6">
            {searchTerm || statusFilter !== 'all' 
              ? 'Try adjusting your search criteria'
              : 'Start by bidding on projects to get your first contract'
            }
          </p>
          <button
            onClick={() => onNavigate('browse-jobs')}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Browse Jobs
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {contracts.map((contract) => {
            const progress = calculateProgress(contract.milestones || []);
            
            return (
              <div
                key={contract.id}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex justify-between items-start mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {contract.project?.title}
                    </h3>
                    <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                      <div className="flex items-center space-x-1">
                        <User className="w-4 h-4" />
                        <span>{contract.client?.full_name}</span>
                      </div>
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                        {contract.project?.category}
                      </span>
                      <span>{contract.project?.duration}</span>
                    </div>
                    <p className="text-gray-700 line-clamp-2">
                      {contract.project?.description}
                    </p>
                  </div>

                  <div className="ml-6 text-right">
                    <div className="text-2xl font-bold text-green-600 mb-1">
                      ${contract.amount}
                    </div>
                    <div className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(contract.status)}`}>
                      {contract.status.toUpperCase()}
                    </div>
                  </div>
                </div>

                {/* Progress Bar for Active Contracts */}
                {contract.status === 'active' && contract.milestones && contract.milestones.length > 0 && (
                  <div className="mb-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Progress</span>
                      <span className="text-sm text-gray-600">{progress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${progress}%` }}
                      ></div>
                    </div>
                  </div>
                )}

                {/* Milestones */}
                {contract.milestones && contract.milestones.length > 0 && (
                  <div className="mb-4">
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Milestones</h4>
                    <div className="space-y-1">
                      {contract.milestones.slice(0, 3).map((milestone: any) => (
                        <div key={milestone.id} className="flex items-center justify-between text-sm">
                          <span className="text-gray-600">{milestone.title}</span>
                          <div className="flex items-center space-x-2">
                            <span className="text-green-600 font-medium">${milestone.amount}</span>
                            <span className={`px-2 py-1 rounded text-xs ${
                              milestone.status === 'completed' || milestone.status === 'approved'
                                ? 'bg-green-100 text-green-800'
                                : milestone.status === 'in_progress'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}>
                              {milestone.status.replace('_', ' ').toUpperCase()}
                            </span>
                          </div>
                        </div>
                      ))}
                      {contract.milestones.length > 3 && (
                        <div className="text-xs text-gray-500">
                          +{contract.milestones.length - 3} more milestones
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                  <div className="text-sm text-gray-600">
                    {timeAgo(contract.created_at)}
                  </div>

                  <div className="flex items-center space-x-2">
                    <button className="flex items-center space-x-1 px-3 py-2 text-gray-600 hover:text-gray-700 hover:bg-gray-50 rounded-lg transition-colors">
                      <MessageCircle className="w-4 h-4" />
                      <span>Message</span>
                    </button>
                    
                    {contract.status === 'active' && (
                      <button className="flex items-center space-x-1 px-3 py-2 bg-blue-600 text-white hover:bg-blue-700 rounded-lg transition-colors">
                        <CheckCircle className="w-4 h-4" />
                        <span>Update Progress</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};