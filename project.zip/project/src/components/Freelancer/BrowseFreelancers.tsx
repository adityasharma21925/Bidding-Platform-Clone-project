import React, { useState, useEffect } from 'react';
import { Search, Filter, MapPin, DollarSign, Star, User, MessageCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { User as UserType } from '../../types';
import { useAuth } from '../../contexts/AuthContext';

interface BrowseFreelancersProps {
  onNavigate: (view: string, data?: any) => void;
}

export const BrowseFreelancers = ({ onNavigate }: BrowseFreelancersProps) => {
  const { userProfile } = useAuth();
  const [freelancers, setFreelancers] = useState<UserType[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [skillFilter, setSkillFilter] = useState('');
  const [rateFilter, setRateFilter] = useState('all');

  const rateRanges = [
    { label: 'All Rates', value: 'all' },
    { label: 'Under $25/hr', value: '0-25' },
    { label: '$25 - $50/hr', value: '25-50' },
    { label: '$50 - $100/hr', value: '50-100' },
    { label: 'Over $100/hr', value: '100+' },
  ];

  useEffect(() => {
    fetchFreelancers();
  }, [searchTerm, skillFilter, rateFilter]);

  const fetchFreelancers = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('users')
        .select('*')
        .eq('user_type', 'freelancer')
        .order('rating', { ascending: false });

      const { data, error } = await query;
      if (error) throw error;

      let filteredFreelancers = data || [];

      // Apply filters
      if (searchTerm) {
        filteredFreelancers = filteredFreelancers.filter(freelancer =>
          freelancer.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          freelancer.bio?.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }

      if (skillFilter) {
        filteredFreelancers = filteredFreelancers.filter(freelancer =>
          freelancer.skills?.some(skill => 
            skill.toLowerCase().includes(skillFilter.toLowerCase())
          )
        );
      }

      if (rateFilter !== 'all') {
        const [min, max] = rateFilter.split('-');
        filteredFreelancers = filteredFreelancers.filter(freelancer => {
          if (!freelancer.hourly_rate) return false;
          if (max === '+') {
            return freelancer.hourly_rate >= parseInt(min);
          } else {
            return freelancer.hourly_rate >= parseInt(min) && freelancer.hourly_rate <= parseInt(max);
          }
        });
      }

      setFreelancers(filteredFreelancers);
    } catch (error) {
      console.error('Error fetching freelancers:', error);
    } finally {
      setLoading(false);
    }
  };

  const startConversation = async (freelancerId: string) => {
    if (!userProfile) return;

    try {
      // Create a new message to start conversation
      const { error } = await supabase.from('messages').insert([
        {
          sender_id: userProfile.id,
          receiver_id: freelancerId,
          content: 'Hi! I\'m interested in discussing a potential project with you.',
        },
      ]);

      if (error) throw error;
      onNavigate('messages');
    } catch (error) {
      console.error('Error starting conversation:', error);
    }
  };

  if (userProfile?.user_type !== 'client') {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Access Restricted</h2>
          <p className="text-gray-600">Only clients can browse freelancers.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Browse Freelancers</h1>
        <p className="text-gray-600">Find talented freelancers for your projects</p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search freelancers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <input
            type="text"
            placeholder="Filter by skill..."
            value={skillFilter}
            onChange={(e) => setSkillFilter(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />

          <select
            value={rateFilter}
            onChange={(e) => setRateFilter(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            {rateRanges.map((range) => (
              <option key={range.value} value={range.value}>
                {range.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Results */}
      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-gray-600 mt-4">Loading freelancers...</p>
        </div>
      ) : freelancers.length === 0 ? (
        <div className="text-center py-12">
          <h3 className="text-lg font-medium text-gray-900 mb-2">No freelancers found</h3>
          <p className="text-gray-600">Try adjusting your search criteria</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {freelancers.map((freelancer) => (
            <div
              key={freelancer.id}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
            >
              <div className="text-center mb-4">
                <div className="w-16 h-16 bg-gray-300 rounded-full flex items-center justify-center mx-auto mb-3">
                  <User className="w-8 h-8 text-gray-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">{freelancer.full_name}</h3>
                {freelancer.location && (
                  <div className="flex items-center justify-center space-x-1 text-gray-600 mt-1">
                    <MapPin className="w-4 h-4" />
                    <span className="text-sm">{freelancer.location}</span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-center space-x-4 mb-4">
                {freelancer.rating && freelancer.rating > 0 && (
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{freelancer.rating.toFixed(1)}</span>
                  </div>
                )}
                {freelancer.hourly_rate && (
                  <div className="flex items-center space-x-1 text-green-600">
                    <DollarSign className="w-4 h-4" />
                    <span className="text-sm font-medium">${freelancer.hourly_rate}/hr</span>
                  </div>
                )}
              </div>

              {freelancer.bio && (
                <p className="text-gray-600 text-sm mb-4 line-clamp-3">{freelancer.bio}</p>
              )}

              {freelancer.skills && freelancer.skills.length > 0 && (
                <div className="mb-4">
                  <div className="flex flex-wrap gap-1">
                    {freelancer.skills.slice(0, 4).map((skill) => (
                      <span
                        key={skill}
                        className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs"
                      >
                        {skill}
                      </span>
                    ))}
                    {freelancer.skills.length > 4 && (
                      <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs">
                        +{freelancer.skills.length - 4} more
                      </span>
                    )}
                  </div>
                </div>
              )}

              <div className="flex space-x-2">
                <button
                  onClick={() => startConversation(freelancer.id)}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2 px-4 rounded-lg hover:from-blue-700 hover:to-purple-700 transition-colors flex items-center justify-center space-x-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Contact</span>
                </button>
              </div>

              <div className="mt-3 text-center text-xs text-gray-500">
                {freelancer.total_jobs || 0} jobs completed
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};