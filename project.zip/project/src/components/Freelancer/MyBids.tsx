import React, { useState, useEffect } from 'react';
import { Search, Eye, Clock, DollarSign, User, CheckCircle, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Bid } from '../../types';

interface MyBidsProps {
  onNavigate: (view: string, data?: any) => void;
}

export const MyBids = ({ onNavigate }: MyBidsProps) => {
  const { userProfile } = useAuth();
  const [bids, setBids] = useState<Bid[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    fetchBids();
  }, [searchTerm, statusFilter]);

  const fetchBids = async () => {
    if (!userProfile) return;

    setLoading(true);
    try {
      let query = supabase
        .from('bids')
        .select(`
          *,
          project:projects!bids_project_id_fkey(
            id,
            title,
            budget_min,
            budget_max,
            status,
            category,
            client:users!projects_client_id_fkey(full_name, avatar_url, rating)
          )
        `)
        .eq('freelancer_id', userProfile.id)
        .order('created_at', { ascending: false });

      if (statusFilter !== 'all') {
        query = query.eq('status', statusFilter);
      }

      const { data, error } = await query;
      if (error) throw error;

      let filteredBids = data || [];
      if (searchTerm) {
        filteredBids = filteredBids.filter(bid =>
          bid.project?.title.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }

      setBids(filteredBids);
    } catch (error) {
      console.error('Error fetching bids:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'accepted':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'accepted':
        return <CheckCircle className="w-4 h-4" />;
      case 'rejected':
        return <X className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const timeAgo = (date: string) => {
    const now = new Date();
    const submitted = new Date(date);
    const diffInDays = Math.floor((now.getTime() - submitted.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) return 'Today';
    if (diffInDays === 1) return '1 day ago';
    return `${diffInDays} days ago`;
  };

  if (userProfile?.user_type !== 'freelancer') {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Access Restricted</h2>
          <p className="text-gray-600">Only freelancers can view this page.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">My Bids</h1>
        <p className="text-gray-600 mt-1">Track your submitted proposals and their status</p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search by project title..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="accepted">Accepted</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Bids List */}
      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-gray-600 mt-4">Loading bids...</p>
        </div>
      ) : bids.length === 0 ? (
        <div className="text-center py-12">
          <h3 className="text-lg font-medium text-gray-900 mb-2">No bids found</h3>
          <p className="text-gray-600 mb-6">
            {searchTerm || statusFilter !== 'all' 
              ? 'Try adjusting your search criteria'
              : 'Start by browsing and bidding on projects'
            }
          </p>
          <button
            onClick={() => onNavigate('browse-jobs')}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Browse Jobs
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {bids.map((bid) => (
            <div
              key={bid.id}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {bid.project?.title}
                  </h3>
                  <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                    <div className="flex items-center space-x-1">
                      <User className="w-4 h-4" />
                      <span>{bid.project?.client?.full_name}</span>
                    </div>
                    <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                      {bid.project?.category}
                    </span>
                  </div>
                  <p className="text-gray-700 line-clamp-2">{bid.proposal}</p>
                </div>

                <div className="ml-6 text-right">
                  <div className="text-2xl font-bold text-green-600 mb-1">
                    ${bid.amount}
                  </div>
                  <div className="text-sm text-gray-600 mb-2">
                    {bid.delivery_time} days delivery
                  </div>
                  <div className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(bid.status)}`}>
                    {getStatusIcon(bid.status)}
                    <span>{bid.status.toUpperCase()}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <span>Submitted {timeAgo(bid.created_at)}</span>
                  <span>Project Budget: ${bid.project?.budget_min} - ${bid.project?.budget_max}</span>
                  <span className={`px-2 py-1 rounded text-xs ${
                    bid.project?.status === 'open'
                      ? 'bg-green-100 text-green-800'
                      : bid.project?.status === 'in_progress'
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    Project {bid.project?.status?.replace('_', ' ').toUpperCase()}
                  </span>
                </div>

                <button
                  onClick={() => onNavigate('project-details', bid.project)}
                  className="flex items-center space-x-1 px-4 py-2 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
                >
                  <Eye className="w-4 h-4" />
                  <span>View Project</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};