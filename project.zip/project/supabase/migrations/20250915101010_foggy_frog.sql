/*
  # Complete Freelance Platform Database Schema

  1. New Tables
    - `users` - User profiles for clients and freelancers
    - `projects` - Job postings by clients
    - `bids` - Proposals submitted by freelancers
    - `contracts` - Accepted bids that become active contracts
    - `milestones` - Contract milestones for project tracking
    - `messages` - Communication between users
    - `notifications` - System notifications for users
    - `reviews` - Reviews and ratings after project completion

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
    - Separate policies for clients and freelancers based on user roles

  3. Features
    - Full-text search on projects
    - Automatic timestamp tracking
    - Status enums for projects, bids, contracts
    - Rating system with averages
*/

-- Users table (extends Supabase auth.users)
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text NOT NULL,
  avatar_url text,
  user_type text NOT NULL CHECK (user_type IN ('client', 'freelancer')),
  bio text DEFAULT '',
  skills text[] DEFAULT '{}',
  hourly_rate numeric,
  location text DEFAULT '',
  rating numeric DEFAULT 0,
  total_jobs integer DEFAULT 0,
  total_earned numeric DEFAULT 0,
  portfolio_urls text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Projects table
CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  budget_min numeric NOT NULL,
  budget_max numeric NOT NULL,
  duration text NOT NULL,
  skills_required text[] NOT NULL DEFAULT '{}',
  status text DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'completed', 'cancelled')),
  bids_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Bids table
CREATE TABLE IF NOT EXISTS bids (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
  freelancer_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  amount numeric NOT NULL,
  proposal text NOT NULL,
  delivery_time integer NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(project_id, freelancer_id)
);

-- Contracts table
CREATE TABLE IF NOT EXISTS contracts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
  client_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  freelancer_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  bid_id uuid REFERENCES bids(id) ON DELETE CASCADE NOT NULL,
  amount numeric NOT NULL,
  status text DEFAULT 'active' CHECK (status IN ('active', 'completed', 'cancelled', 'disputed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Milestones table
CREATE TABLE IF NOT EXISTS milestones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid REFERENCES contracts(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  amount numeric NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'approved')),
  due_date timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE,
  sender_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  receiver_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  content text NOT NULL,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  type text NOT NULL CHECK (type IN ('bid', 'message', 'contract', 'milestone', 'system')),
  is_read boolean DEFAULT false,
  related_id uuid,
  created_at timestamptz DEFAULT now()
);

-- Reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid REFERENCES contracts(id) ON DELETE CASCADE NOT NULL,
  reviewer_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  reviewee_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(contract_id, reviewer_id)
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE bids ENABLE ROW LEVEL SECURITY;
ALTER TABLE contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE milestones ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- RLS Policies

-- Users policies
CREATE POLICY "Users can read all profiles" ON users FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users can update own profile" ON users FOR UPDATE TO authenticated USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON users FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

-- Projects policies
CREATE POLICY "Anyone can read open projects" ON projects FOR SELECT TO authenticated USING (true);
CREATE POLICY "Clients can insert projects" ON projects FOR INSERT TO authenticated 
  WITH CHECK (client_id = auth.uid());
CREATE POLICY "Clients can update own projects" ON projects FOR UPDATE TO authenticated 
  USING (client_id = auth.uid());

-- Bids policies
CREATE POLICY "Users can read bids on their projects" ON bids FOR SELECT TO authenticated
  USING (
    project_id IN (SELECT id FROM projects WHERE client_id = auth.uid()) OR
    freelancer_id = auth.uid()
  );
CREATE POLICY "Freelancers can insert bids" ON bids FOR INSERT TO authenticated
  WITH CHECK (freelancer_id = auth.uid());
CREATE POLICY "Freelancers can update own bids" ON bids FOR UPDATE TO authenticated
  USING (freelancer_id = auth.uid());

-- Contracts policies
CREATE POLICY "Contract participants can read contracts" ON contracts FOR SELECT TO authenticated
  USING (client_id = auth.uid() OR freelancer_id = auth.uid());
CREATE POLICY "Clients can insert contracts" ON contracts FOR INSERT TO authenticated
  WITH CHECK (client_id = auth.uid());
CREATE POLICY "Contract participants can update contracts" ON contracts FOR UPDATE TO authenticated
  USING (client_id = auth.uid() OR freelancer_id = auth.uid());

-- Milestones policies
CREATE POLICY "Contract participants can read milestones" ON milestones FOR SELECT TO authenticated
  USING (
    contract_id IN (
      SELECT id FROM contracts WHERE client_id = auth.uid() OR freelancer_id = auth.uid()
    )
  );
CREATE POLICY "Contract participants can manage milestones" ON milestones FOR ALL TO authenticated
  USING (
    contract_id IN (
      SELECT id FROM contracts WHERE client_id = auth.uid() OR freelancer_id = auth.uid()
    )
  );

-- Messages policies
CREATE POLICY "Users can read their messages" ON messages FOR SELECT TO authenticated
  USING (sender_id = auth.uid() OR receiver_id = auth.uid());
CREATE POLICY "Users can send messages" ON messages FOR INSERT TO authenticated
  WITH CHECK (sender_id = auth.uid());
CREATE POLICY "Users can update their messages" ON messages FOR UPDATE TO authenticated
  USING (sender_id = auth.uid() OR receiver_id = auth.uid());

-- Notifications policies
CREATE POLICY "Users can read own notifications" ON notifications FOR SELECT TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "Users can update own notifications" ON notifications FOR UPDATE TO authenticated
  USING (user_id = auth.uid());

-- Reviews policies
CREATE POLICY "Anyone can read reviews" ON reviews FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users can insert reviews" ON reviews FOR INSERT TO authenticated
  WITH CHECK (reviewer_id = auth.uid());

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
CREATE INDEX IF NOT EXISTS idx_projects_category ON projects(category);
CREATE INDEX IF NOT EXISTS idx_projects_client_id ON projects(client_id);
CREATE INDEX IF NOT EXISTS idx_bids_project_id ON bids(project_id);
CREATE INDEX IF NOT EXISTS idx_bids_freelancer_id ON bids(freelancer_id);
CREATE INDEX IF NOT EXISTS idx_contracts_client_id ON contracts(client_id);
CREATE INDEX IF NOT EXISTS idx_contracts_freelancer_id ON contracts(freelancer_id);
CREATE INDEX IF NOT EXISTS idx_messages_sender_receiver ON messages(sender_id, receiver_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);

-- Full text search index
CREATE INDEX IF NOT EXISTS idx_projects_search ON projects USING gin(to_tsvector('english', title || ' ' || description));

-- Triggers for updating timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON projects FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_bids_updated_at BEFORE UPDATE ON bids FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_contracts_updated_at BEFORE UPDATE ON contracts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_milestones_updated_at BEFORE UPDATE ON milestones FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();