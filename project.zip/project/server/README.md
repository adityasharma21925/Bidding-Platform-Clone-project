Setup

1. Create .env in server/ with:

MONGO_URI=mongodb://127.0.0.1:27017/freelance_marketplace
PORT=4000

2. Install and run

npm install
npm run dev

