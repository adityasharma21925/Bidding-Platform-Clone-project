import mongoose, { Schema, InferSchemaType, Model } from 'mongoose';

export const BID_STATUS = ['pending', 'accepted', 'rejected'] as const;
export type BidStatus = typeof BID_STATUS[number];

const BidSchema = new Schema(
  {
    project: { type: Schema.Types.ObjectId, ref: 'Project', required: true, index: true },
    freelancer: { type: String, required: true, index: true },
    amount: { type: Number, required: true },
    proposal: { type: String, required: true },
    deliveryTime: { type: Number, required: true },
    status: { type: String, enum: BID_STATUS, default: 'pending', index: true },
  },
  { timestamps: true }
);

BidSchema.index({ project: 1, freelancer: 1 }, { unique: true });

export type BidDocument = InferSchemaType<typeof BidSchema> & { _id: mongoose.Types.ObjectId };

export const Bid: Model<BidDocument> =
  mongoose.models.Bid || mongoose.model<BidDocument>('Bid', BidSchema);


