import mongoose, { Schema, InferSchemaType, Model } from 'mongoose';

export const USER_ROLES = ['client', 'freelancer'] as const;
export type UserRole = typeof USER_ROLES[number];

const UserSchema = new Schema(
  {
    email: { type: String, required: true, unique: true, index: true },
    fullName: { type: String, required: true },
    avatarUrl: { type: String },
    userType: { type: String, enum: USER_ROLES, required: true },
    bio: { type: String },
    skills: { type: [String], default: [] },
    hourlyRate: { type: Number },
    location: { type: String },
    rating: { type: Number, default: 0 },
    totalJobs: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export type UserDocument = InferSchemaType<typeof UserSchema> & { _id: mongoose.Types.ObjectId };

export const User: Model<UserDocument> =
  mongoose.models.User || mongoose.model<UserDocument>('User', UserSchema);


