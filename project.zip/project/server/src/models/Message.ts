import mongoose, { Schema, InferSchemaType, Model } from 'mongoose';

const MessageSchema = new Schema(
  {
    project: { type: Schema.Types.ObjectId, ref: 'Project', index: true },
    sender: { type: String, required: true, index: true },
    receiver: { type: String, required: true, index: true },
    content: { type: String, required: true },
    isRead: { type: Boolean, default: false, index: true },
  },
  { timestamps: true }
);

MessageSchema.index({ sender: 1, receiver: 1, createdAt: -1 });

export type MessageDocument = InferSchemaType<typeof MessageSchema> & { _id: mongoose.Types.ObjectId };

export const Message: Model<MessageDocument> =
  mongoose.models.Message || mongoose.model<MessageDocument>('Message', MessageSchema);


