import mongoose, { Schema, InferSchemaType, Model } from 'mongoose';

export const PROJECT_STATUS = ['open', 'in_progress', 'completed', 'cancelled'] as const;
export type ProjectStatus = typeof PROJECT_STATUS[number];

const ProjectSchema = new Schema(
  {
    client: { type: String, required: true, index: true },
    title: { type: String, required: true },
    description: { type: String, required: true },
    category: { type: String, required: true },
    budgetMin: { type: Number, required: true },
    budgetMax: { type: Number, required: true },
    duration: { type: String, required: true },
    skillsRequired: { type: [String], default: [] },
    status: { type: String, enum: PROJECT_STATUS, default: 'open', index: true },
  },
  { timestamps: true }
);

export type ProjectDocument = InferSchemaType<typeof ProjectSchema> & { _id: mongoose.Types.ObjectId };

export const Project: Model<ProjectDocument> =
  mongoose.models.Project || mongoose.model<ProjectDocument>('Project', ProjectSchema);


