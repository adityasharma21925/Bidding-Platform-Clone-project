import mongoose, { Schema, InferSchemaType, Model } from 'mongoose';

export const CONTRACT_STATUS = ['active', 'completed', 'cancelled', 'disputed'] as const;
export type ContractStatus = typeof CONTRACT_STATUS[number];

const ContractSchema = new Schema(
  {
    project: { type: Schema.Types.ObjectId, ref: 'Project', required: true, index: true },
    client: { type: String, required: true, index: true },
    freelancer: { type: String, required: true, index: true },
    bid: { type: Schema.Types.ObjectId, ref: 'Bid', required: true },
    amount: { type: Number, required: true },
    status: { type: String, enum: CONTRACT_STATUS, default: 'active', index: true },
  },
  { timestamps: true }
);

export type ContractDocument = InferSchemaType<typeof ContractSchema> & { _id: mongoose.Types.ObjectId };

export const Contract: Model<ContractDocument> =
  mongoose.models.Contract || mongoose.model<ContractDocument>('Contract', ContractSchema);


