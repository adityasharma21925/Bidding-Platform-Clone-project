import mongoose, { Schema, InferSchemaType, Model } from 'mongoose';

export const MILESTONE_STATUS = ['pending', 'in_progress', 'completed', 'approved'] as const;
export type MilestoneStatus = typeof MILESTONE_STATUS[number];

const MilestoneSchema = new Schema(
  {
    contract: { type: Schema.Types.ObjectId, ref: 'Contract', required: true, index: true },
    title: { type: String, required: true },
    description: { type: String },
    amount: { type: Number, required: true },
    status: { type: String, enum: MILESTONE_STATUS, default: 'pending', index: true },
    dueDate: { type: Date },
  },
  { timestamps: true }
);

export type MilestoneDocument = InferSchemaType<typeof MilestoneSchema> & { _id: mongoose.Types.ObjectId };

export const Milestone: Model<MilestoneDocument> =
  mongoose.models.Milestone || mongoose.model<MilestoneDocument>('Milestone', MilestoneSchema);


