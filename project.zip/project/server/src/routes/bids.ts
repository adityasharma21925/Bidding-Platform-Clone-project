import { Router } from 'express';
import { z } from 'zod';
import { Bid } from '../models/Bid';
import { Project } from '../models/Project';
import { Contract } from '../models/Contract';

const router = Router();

const createBidSchema = z.object({
  projectId: z.string(),
  freelancerId: z.string(),
  amount: z.number().positive(),
  proposal: z.string().min(10),
  deliveryTime: z.number().int().positive(),
});

router.post('/', async (req, res) => {
  try {
    const input = createBidSchema.parse(req.body);
    const bid = await Bid.create({
      project: input.projectId,
      freelancer: input.freelancerId,
      amount: input.amount,
      proposal: input.proposal,
      deliveryTime: input.deliveryTime,
    });
    res.status(201).json(bid);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// List bids by project
router.get('/of-project/:projectId', async (req, res) => {
  try {
    const { projectId } = req.params;
    const bids = await Bid.find({ project: projectId }).sort({ createdAt: -1 });
    res.json(bids);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// List bids by freelancer
router.get('/of-user/:freelancerId', async (req, res) => {
  try {
    const { freelancerId } = req.params;
    const bids = await Bid.find({ freelancer: freelancerId }).sort({ createdAt: -1 }).populate('project', 'title budgetMin budgetMax status category client');
    res.json(bids);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

const acceptBidSchema = z.object({ bidId: z.string() });

router.post('/accept', async (req, res) => {
  const session = await (await import('mongoose')).default.startSession();
  session.startTransaction();
  try {
    const { bidId } = acceptBidSchema.parse(req.body);
    const bid = await Bid.findById(bidId).session(session);
    if (!bid) throw new Error('Bid not found');

    const project = await Project.findById(bid.project).session(session);
    if (!project) throw new Error('Project not found');

    // Create contract
    const contract = await Contract.create([
      {
        project: bid.project,
        client: project.client,
        freelancer: bid.freelancer,
        bid: bid._id,
        amount: bid.amount,
      },
    ], { session });

    // Update bid status accepted
    await Bid.updateOne({ _id: bid._id }, { status: 'accepted' }).session(session);
    // Reject other bids
    await Bid.updateMany({ project: bid.project, _id: { $ne: bid._id } }, { status: 'rejected' }).session(session);
    // Update project status
    await Project.updateOne({ _id: bid.project }, { status: 'in_progress' }).session(session);

    await session.commitTransaction();
    res.json({ contract: contract[0] });
  } catch (err: any) {
    await session.abortTransaction();
    res.status(400).json({ error: err.message });
  } finally {
    session.endSession();
  }
});

export default router;


