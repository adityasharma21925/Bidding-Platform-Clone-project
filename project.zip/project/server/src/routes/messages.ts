import { Router } from 'express';
import { z } from 'zod';
import { Message } from '../models/Message';

const router = Router();

router.get('/conversations/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const messages = await Message.find({ $or: [{ sender: userId }, { receiver: userId }] })
      .sort({ createdAt: -1 })
      .populate('sender', 'fullName avatarUrl')
      .populate('receiver', 'fullName avatarUrl');

    const map = new Map<string, any>();
    for (const m of messages) {
      const partnerId = String(m.sender._id) === userId ? String((m.receiver as any)._id) : String(m.sender._id);
      if (!map.has(partnerId)) {
        map.set(partnerId, {
          partnerId,
          partner: String(m.sender._id) === userId ? m.receiver : m.sender,
          lastMessage: m,
          unreadCount: 0,
        });
      }
      if (!m.isRead && String(m.receiver._id) === userId) {
        map.get(partnerId).unreadCount++;
      }
    }

    res.json(Array.from(map.values()));
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch conversations' });
  }
});

router.get('/:userId/:partnerId', async (req, res) => {
  try {
    const { userId, partnerId } = req.params;
    const msgs = await Message.find({
      $or: [
        { sender: userId, receiver: partnerId },
        { sender: partnerId, receiver: userId },
      ],
    })
      .sort({ createdAt: 1 })
      .populate('sender', 'fullName avatarUrl')
      .populate('receiver', 'fullName avatarUrl');

    // mark as read
    await Message.updateMany({ sender: partnerId, receiver: userId, isRead: false }, { isRead: true });

    res.json(msgs);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch messages' });
  }
});

const sendSchema = z.object({
  senderId: z.string(),
  receiverId: z.string(),
  content: z.string().min(1),
  projectId: z.string().optional(),
});

router.post('/', async (req, res) => {
  try {
    const input = sendSchema.parse(req.body);
    const msg = await Message.create({
      sender: input.senderId,
      receiver: input.receiverId,
      content: input.content,
      project: input.projectId,
    });
    res.status(201).json(msg);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

export default router;


