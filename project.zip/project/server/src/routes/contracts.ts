import { Router } from 'express';
import { z } from 'zod';
import { Contract } from '../models/Contract';
import { Milestone } from '../models/Milestone';

const router = Router();

router.get('/me/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const contracts = await Contract.find({ $or: [{ client: userId }, { freelancer: userId }] })
      .sort({ createdAt: -1 })
      .populate('project', 'title description category duration')
      .populate('client', 'fullName avatarUrl rating')
      .populate('freelancer', 'fullName avatarUrl rating');

    const contractIds = contracts.map(c => c._id);
    const milestones = await Milestone.find({ contract: { $in: contractIds } });

    const milestonesByContract = milestones.reduce<Record<string, any[]>>((acc, m) => {
      const key = String(m.contract);
      acc[key] = acc[key] || [];
      acc[key].push(m);
      return acc;
    }, {});

    const result = contracts.map(c => ({
      ...c.toObject(),
      milestones: milestonesByContract[String(c._id)] || [],
    }));

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch contracts' });
  }
});

const updateMilestoneSchema = z.object({
  status: z.enum(['pending', 'in_progress', 'completed', 'approved']),
});

router.patch('/milestones/:id', async (req, res) => {
  try {
    const input = updateMilestoneSchema.parse(req.body);
    const ms = await Milestone.findByIdAndUpdate(
      req.params.id,
      { status: input.status },
      { new: true }
    );
    if (!ms) return res.status(404).json({ error: 'Not found' });
    res.json(ms);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

export default router;


