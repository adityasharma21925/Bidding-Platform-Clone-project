import { Router } from 'express';
import Stripe from 'stripe';

const router = Router();

const STRIPE_SECRET = process.env.STRIPE_SECRET_KEY || '';
const stripe = new Stripe(STRIPE_SECRET, { apiVersion: '2024-06-20' });

router.post('/payment-intents', async (req, res) => {
  try {
    const { amount, currency = 'usd' } = req.body as { amount: number; currency?: string };
    if (!amount || amount <= 0) return res.status(400).json({ error: 'Invalid amount' });

    const pi = await stripe.paymentIntents.create({ amount: Math.round(amount * 100), currency });
    res.json({ clientSecret: pi.client_secret });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
