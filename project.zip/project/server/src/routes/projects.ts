import { Router } from 'express';
import { z } from 'zod';
import { Project } from '../models/Project';

const router = Router();

const createProjectSchema = z.object({
  clientId: z.string(),
  title: z.string().min(3),
  description: z.string().min(10),
  category: z.string().min(2),
  budgetMin: z.number().positive(),
  budgetMax: z.number().positive(),
  duration: z.string().min(2),
  skillsRequired: z.array(z.string()).default([]),
});

router.post('/', async (req, res) => {
  try {
    const input = createProjectSchema.parse(req.body);
    const project = await Project.create({
      client: input.clientId,
      title: input.title,
      description: input.description,
      category: input.category,
      budgetMin: input.budgetMin,
      budgetMax: input.budgetMax,
      duration: input.duration,
      skillsRequired: input.skillsRequired,
    });
    res.status(201).json(project);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/', async (_req, res) => {
  try {
    const projects = await Project.find({ status: 'open' })
      .sort({ createdAt: -1 });
    res.json(projects);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch projects' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const project = await Project.findById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });
    res.json(project);
  } catch (err: any) {
    res.status(400).json({ error: 'Invalid id' });
  }
});

export default router;


